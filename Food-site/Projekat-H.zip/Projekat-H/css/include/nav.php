<nav>
  <div class="brand"> Our Store </div>
  <div class="links">
    <a href="home.php"> Home </a>
    <a href="about.php"> About </a>
    <a href="logout.php" style="position: absolute; right: 50px;"> Logout </a>
  </div>
</nav>