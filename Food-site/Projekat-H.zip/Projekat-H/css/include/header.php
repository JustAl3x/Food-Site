<header>
    <h1> Dobrodosli u nasu prodavnicu! </h1> 
    <p class="sub-title">
        Nasa prodavnica se bavi izradom najukusnije hrane sa najstarijeim receptima na svetu!
    </p>
</header>